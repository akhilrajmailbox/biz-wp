<?php
/**
 * BuddyPress Members Classes.
 *
 * @package BuddyPress
 * @subpackage MembersClasses
 * @since 2.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

require dirname( __FILE__ ) . '/classes/class-bp-signup.php';
